﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_Assignment {
    class Program {
        
        enum Months {January = 1, February, March, April, May, June, July, August, September, October, November, December}
        
        static int[] daysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        const int MONTHS_IN_YEAR = 12;

       

        static void Main(string[] args) {

            int[][] rainfall = new int[MONTHS_IN_YEAR] [];
           

            Welcome();

            

            ExitProgram();


        }//end Main
       
        static void Welcome() {
            Console.WriteLine("\n\n\t Welcome to Yearly Rainfall Report \n\n");
        }//end Welcome
        
        static void ExitProgram() {
            Console.Write("\n\nPress any key to exit.");
            Console.ReadKey();
        }//end ExitProgram

    }//end class
}//end namespace
