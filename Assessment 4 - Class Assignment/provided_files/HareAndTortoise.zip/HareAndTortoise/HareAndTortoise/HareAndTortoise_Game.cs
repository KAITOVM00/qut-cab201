﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HareAndTortoise {
    public static class HareAndTortoise_Game {
/*
        private static BindingList<Player> players = new BindingList<Player>();
        public static BindingList<Player> Players {
            get {
                return players;
            }
        }

        public static void SetUpGame(){

            Board.SetUpBoard();
 
            //more code to be added later
        }// end SetUpGame
*/

        // MORE METHODS TO BE ADDED HERE LATER
        
    }//end class
}//end namespace
